#ifndef PARSER
#define PARSER
#include <iostream>

bool getAndParseMSR(std::ifstream &inputTrace, reqAtom *newn);
bool getAndParseTrace(std::ifstream &inputTrace, reqAtom *newn);
	

#endif
