update Room set price = (1.05 * price);
