select hotelNo, count(*) as count from Room group by hotelNo;
